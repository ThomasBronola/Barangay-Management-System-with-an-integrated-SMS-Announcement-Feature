-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2022 at 12:55 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brgy53`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `trail_id` int(11) NOT NULL,
  `trail_user` varchar(128) NOT NULL,
  `trail_utype` varchar(128) NOT NULL,
  `trail_ip` varchar(128) NOT NULL,
  `trail_action` varchar(128) NOT NULL,
  `trail_date` varchar(128) NOT NULL,
  `trail_time` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(128) NOT NULL,
  `announce` mediumtext NOT NULL,
  `announcement_date` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `blotter`
--

CREATE TABLE `blotter` (
  `id` int(11) NOT NULL,
  `reported_date` varchar(128) NOT NULL,
  `complainant` varchar(128) NOT NULL,
  `defendant` varchar(128) NOT NULL,
  `report` mediumtext NOT NULL,
  `official_incharge` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blotter`
--

INSERT INTO `blotter` (`id`, `reported_date`, `complainant`, `defendant`, `report`, `official_incharge`) VALUES
(3, '06/07/2022', 'Thomas', 'Jhon', 'This is test report.(with edit)\r\n\r\nAddition of official in-charge in the database.\r\n\r\nThe official in-charge will be the one who is logged in and writing this report.', 'Thomas Broñola'),
(4, '07/07/2022', 'Thomas', 'Agev ed', 'test', 'Thomas Broñola'),
(5, '07/07/2022', 'Thomas', 'Agev ed', 'This is test report #2 (with edit)\r\n\r\n\r\n\r\n\r\n\r\n\r\nHatdog\r\n\r\n\r\n\r\n\r\n\r\nCheesedog\r\n\r\n\r\n\r\n\r\n\r\nFootlong', 'Thomas Broñola'),
(6, '09/10/2022', 'Thomas', 'Agev ed', 'This is test report #3 (with edit)\r\n\r\n\r\n\r\n\r\n\r\n\r\nHatdog\r\n\r\n\r\n\r\n\r\n\r\nCheesedog\r\n\r\n\r\n\r\n\r\n\r\nFootlong', 'Thomas Broñola'),
(7, '08/06/2022', 'Students', 'CCIS', 'Extremely Bad! Puro pahirap, magbibigay ng grandeng gawain which is given to the CS for more than a month and is given to IT for only a week before deadline. So much hate.', 'Thomas Broñola');

-- --------------------------------------------------------

--
-- Table structure for table `files_db`
--

CREATE TABLE `files_db` (
  `files_user_id` int(11) NOT NULL,
  `files_id` int(11) NOT NULL,
  `files_activity` varchar(255) NOT NULL COMMENT 'INDICATOR FOR WHAT ACTIVITY ',
  `files_name` varchar(255) NOT NULL,
  `files_size` int(11) NOT NULL,
  `files_downloads` int(11) NOT NULL,
  `files_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `id` int(11) NOT NULL,
  `auth` varchar(128) NOT NULL,
  `sid` varchar(128) NOT NULL,
  `phone` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`id`, `auth`, `sid`, `phone`) VALUES
(1, '067ea4636007820c2f021a0a9edebbb4', 'ACd6c0d5cf6d9fb0166f4d8b927563a03d', '+13082808881');

-- --------------------------------------------------------

--
-- Table structure for table `sms_archive`
--

CREATE TABLE `sms_archive` (
  `message` mediumtext NOT NULL,
  `message_date` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `user_password` varchar(128) NOT NULL,
  `user_type` varchar(128) NOT NULL,
  `full_name` varchar(128) NOT NULL,
  `user_contact` varchar(13) NOT NULL,
  `user_address` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `user_password`, `user_type`, `full_name`, `user_contact`, `user_address`) VALUES
(1, 'bronolathomas@gmail.com', '$2y$10$MTYBqd/.Kwu8EXuGz904SeyAXoePpXfwLRgtPrAAwtGvnkGQnpLwq', 'systemadmin', 'Thomas Broñola', '+639475892286', 'Quezon City'),
(11, 'jhonberniedevega@gmail.com', '$2y$10$JZy0uo3AHHABESQhnAJkbuWhE0ABnAbgxCoHbm.xzP6tDUXrwRBdK', 'client', 'Jhon Bernie De Vega', '+639154273628', 'Caloocan City'),
(12, 'tester@gmail.com', '$2y$10$lpUo0Q5Giy0WI0DY4O01reg.xPAUGUzsJk5ZfTufvYdB9S8HO2YQq', 'tanod', 'tester', '+639999999999', '#022 dyan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`trail_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blotter`
--
ALTER TABLE `blotter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files_db`
--
ALTER TABLE `files_db`
  ADD PRIMARY KEY (`files_id`);

--
-- Indexes for table `sms`
--
ALTER TABLE `sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `trail_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blotter`
--
ALTER TABLE `blotter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `files_db`
--
ALTER TABLE `files_db`
  MODIFY `files_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms`
--
ALTER TABLE `sms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
